# CS 181 Spring 2024 Homeworks

Homeworks will be released from this GitHub repository. The recommended way to download files is to clone this repository using

```
git clone https://github.com/harvard-ml-courses/cs181-s24-homeworks.git
```

and then run `git pull` to fetch the most recent updates. You can also click the green `Code` button and then `Download ZIP`.

[See the course schedule here.](https://docs.google.com/spreadsheets/d/1BHySWJvxphouMu7tVaXKcg0cptAbmOKlCTjVtOPCLWw/edit?usp=sharing)

Please request clarifications through [our Ed discussion board](https://edstem.org/us/courses/51511/discussion/) under the corresponding label.
